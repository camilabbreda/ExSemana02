package aula03interface.entities;

public interface Forma {
    double area();
}