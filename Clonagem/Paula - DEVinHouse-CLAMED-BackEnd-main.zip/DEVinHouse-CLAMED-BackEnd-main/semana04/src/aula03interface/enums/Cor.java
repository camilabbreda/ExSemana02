package aula03interface.enums;

public enum Cor {
    Black,
    White;
}
