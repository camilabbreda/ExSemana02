package aula01.entities;

public class SavingsAccountPlus extends SavingsAccount {
}
