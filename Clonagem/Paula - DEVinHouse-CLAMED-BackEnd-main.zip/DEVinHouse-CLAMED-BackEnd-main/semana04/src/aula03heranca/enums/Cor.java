package aula03heranca.enums;

public enum Cor {

    Black,
    White;
}
