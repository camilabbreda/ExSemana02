package com.example.caderno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadernoApplicationTests {

    @Test
    void contextLoads() {
    }

}
