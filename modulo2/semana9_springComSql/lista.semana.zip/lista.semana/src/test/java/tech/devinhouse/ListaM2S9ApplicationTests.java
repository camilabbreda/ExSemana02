package tech.devinhouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListaM2S9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
