package tech.devinhouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListaM2S9Application {

	public static void main(String[] args) {
		SpringApplication.run(ListaM2S9Application.class, args);
	}

}
