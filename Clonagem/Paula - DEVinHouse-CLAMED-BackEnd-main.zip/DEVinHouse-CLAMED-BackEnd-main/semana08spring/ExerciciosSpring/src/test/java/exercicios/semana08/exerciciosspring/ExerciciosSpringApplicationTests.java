package exercicios.semana08.exerciciosspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerciciosSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
