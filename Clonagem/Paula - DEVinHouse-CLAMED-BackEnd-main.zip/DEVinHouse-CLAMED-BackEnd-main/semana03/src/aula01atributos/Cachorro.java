package aula01atributos;

public class Cachorro {
    String nome;
    Integer idade;
    String raca;
    Character sexo; // m, f
}
