package aula02.modificadores.produto;

public class Produto {
    public String nome;
}
