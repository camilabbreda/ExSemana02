package aula02.produto;

public class Main {
    public static void main(String[] args) {
        Produto produto = new Produto("Sonho de valsa", "12/2022", 2.25);
        produto.verificaVcto(10, 2022);
    }
}
