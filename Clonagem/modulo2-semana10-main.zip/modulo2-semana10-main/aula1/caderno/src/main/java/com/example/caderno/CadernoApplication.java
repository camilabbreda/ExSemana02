package com.example.caderno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadernoApplication {

    public static void main(String[] args) {
        SpringApplication.run(CadernoApplication.class, args);
    }

}
