package tech.devinhouse.meurh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeuRhApplicationTests {

	@Test
	void contextLoads() {
	}

}
