package tech.semana09;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerciciosM02S09ApplicationTests {

	@Test
	void contextLoads() {
	}

}
