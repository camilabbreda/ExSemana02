package tech.semana09;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciciosM02S09Application {

	public static void main(String[] args) {
		SpringApplication.run(ExerciciosM02S09Application.class, args);
	}

}
